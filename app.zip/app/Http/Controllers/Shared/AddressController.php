<?php

namespace App\Http\Controllers;

class AddressController extends Controller
{
}
